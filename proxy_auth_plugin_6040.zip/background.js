
var config = {
  mode: "fixed_servers",
  rules: {
    singleProxy: { scheme: "http", host: "45.38.126.104", port: parseInt(5393) },
    bypassList: ["localhost"]
  }
};
chrome.proxy.settings.set({value: config, scope: "regular"}, function(){});
function callbackFn(details) {
  details.requestHeaders.push({
    name: "Proxy-Authorization",
    value: "Basic bmZ0aXV2ZnU6OHJpczdmdTVyZ3Ju"
  });
  return {requestHeaders: details.requestHeaders};
}
chrome.webRequest.onBeforeSendHeaders.addListener(
  callbackFn,
  {urls: ["<all_urls>"]},
  ["blocking","requestHeaders"]
);
